# Apartman Benjo – pravi sistem rezervacija

Ovaj projekt više nije samo statični HTML.

## Šta radi

- `public/index.html` – javna web stranica apartmana
- `POST /api/reservations` – prima rezervacije sa forme
- SQLite baza – čuva svaku rezervaciju
- Gmail / Nodemailer – šalje novu rezervaciju na `vhs.osmanovic@gmail.com`
- Gost dobija automatsku potvrdu na svoj e-mail
- `public/admin.html` – privatni pregled rezervacija
- Admin može označiti rezervaciju kao `new`, `confirmed`, `cancelled` ili `completed`
- Telefon i WhatsApp: `+43 676 911 5665`

---

# 1. Instalacija na Windows računaru

Instaliraj Node.js 20 ili noviji.

Otvori folder projekta u Command Prompt / PowerShell i pokreni:

```bash
npm install
```

Kopiraj `.env.example` i nazovi kopiju `.env`.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Zatim otvori `.env` u Notepadu.

---

# 2. Gmail – da e-mailovi STVARNO odlaze

U `.env` već je:

```env
OWNER_EMAIL=vhs.osmanovic@gmail.com
SMTP_USER=vhs.osmanovic@gmail.com
```

Ne upisuj običnu Gmail lozinku.

Na Google računu uključi 2-Step Verification i napravi **App Password**.
Dobijeni 16-znamenkasti App Password stavi ovdje:

```env
SMTP_PASS=OVDJE_STAVI_APP_PASSWORD
```

Primjer:

```env
SMTP_PASS=abcd efgh ijkl mnop
```

Server koristi taj App Password samo za slanje e-mailova.

---

# 3. Admin lozinka

U `.env` promijeni:

```env
ADMIN_KEY=CHANGE_THIS_TO_A_LONG_RANDOM_SECRET
```

u nešto dugo i privatno, npr.:

```env
ADMIN_KEY=Benjo-2026-Moj-Admin-9x!82Q
```

Tu vrijednost NIKOME ne objavljuj.

Admin stranicu otvaraš na:

```text
http://localhost:3000/admin.html
```

i tamo uneseš `ADMIN_KEY`.

---

# 4. Pokretanje

Pokreni:

```bash
npm start
```

Otvori:

```text
http://localhost:3000
```

Admin:

```text
http://localhost:3000/admin.html
```

Test servera:

```text
http://localhost:3000/api/health
```

Ako piše:

```json
{"ok":true,"emailConfigured":true}
```

SMTP je unesen.

---

# 5. Gdje je baza?

Lokalno se automatski napravi:

```text
data/reservations.db
```

To je SQLite baza.

Ne moraš ručno praviti tablice – server ih napravi sam pri prvom pokretanju.

---

# 6. Kako izgleda tok rezervacije

Gost popuni:

- dolazak
- odlazak
- broj gostiju
- ime
- e-mail
- poruku

Klikne **Buchungsanfrage senden**.

Server onda:

1. provjeri podatke
2. spremi rezervaciju u SQLite
3. pošalje tebi e-mail na `vhs.osmanovic@gmail.com`
4. pošalje gostu potvrdu
5. vrati broj rezervacije, npr. `#14`

---

# 7. Objavljivanje na internetu

Ovo više NE može biti objavljeno kao običan `index.html` na statičnom hostingu jer treba Node.js server.

Treba hosting koji pokreće Node.js i omogućava trajno spremanje baze.

## Folder koji uploaduješ

Uploaduj CIJELI folder:

```text
apartman-benjo-booking-system/
```

Treba sadržavati:

```text
apartman-benjo-booking-system/
├── public/
│   ├── index.html
│   └── admin.html
├── data/
├── server.js
├── package.json
├── .env.example
└── .gitignore
```

`.env` se obično NE uploaduje u Git. Tajne vrijednosti dodaješ kroz hosting Environment Variables.

## Environment Variables na hostingu

Dodaj:

```text
OWNER_EMAIL = vhs.osmanovic@gmail.com
SMTP_USER = vhs.osmanovic@gmail.com
SMTP_PASS = tvoj Google App Password
ADMIN_KEY = tvoja privatna admin lozinka
DB_PATH = /data/reservations.db
```

Za SQLite u produkciji hosting mora imati persistent/volume disk montiran na `/data`.

---

# VAŽNO

Nikada mi ne šalji svoju običnu Gmail lozinku.

Ako budeš slao Google App Password nekome, ta osoba može slati mail preko tog Gmail računa dok ga ne opozoveš. Najsigurnije je da ga sam upišeš direktno u `.env` ili u tajne Environment Variables na hostingu.
