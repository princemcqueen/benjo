const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
require("dotenv").config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const OWNER_EMAIL = process.env.OWNER_EMAIL || "vhs.osmanovic@gmail.com";
const SMTP_USER = process.env.SMTP_USER || "";
const SMTP_PASS = process.env.SMTP_PASS || "";
const ADMIN_KEY = process.env.ADMIN_KEY || "";
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "reservations.db");

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    guest_email TEXT NOT NULL,
    arrival TEXT NOT NULL,
    departure TEXT NOT NULL,
    guests INTEGER NOT NULL,
    message TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'new',
    email_status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE INDEX IF NOT EXISTS idx_reservations_created
  ON reservations(created_at DESC);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "50kb" }));
app.use(express.urlencoded({ extended: false }));

const bookingLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Zu viele Anfragen. Bitte versuchen Sie es später erneut." }
});

app.use(express.static(path.join(__dirname, "public")));

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || "").trim());
}
function cleanText(value, max = 2000) {
  return String(value || "").trim().slice(0, max);
}
function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function getTransporter() {
  if (!SMTP_USER || !SMTP_PASS) {
    throw new Error("SMTP ist nicht konfiguriert. SMTP_USER und SMTP_PASS fehlen.");
  }
  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS
    }
  });
}

function ownerMailHtml(r) {
  return `
  <div style="font-family:Arial,sans-serif;background:#f4f6f5;padding:28px">
    <div style="max-width:640px;margin:auto;background:#fff;border-radius:18px;padding:28px;border:1px solid #e3e8e5">
      <div style="font-size:12px;color:#2b6553;font-weight:700;letter-spacing:1.5px">APARTMAN BENJO</div>
      <h1 style="margin:8px 0 22px;color:#173a2f">Neue Buchungsanfrage #${r.id}</h1>
      <table style="width:100%;border-collapse:collapse;color:#25352f">
        <tr><td style="padding:10px 0;color:#718078">Name</td><td style="padding:10px 0;font-weight:700">${escapeHtml(r.name)}</td></tr>
        <tr><td style="padding:10px 0;color:#718078">E-Mail</td><td style="padding:10px 0"><a href="mailto:${escapeHtml(r.email)}">${escapeHtml(r.email)}</a></td></tr>
        <tr><td style="padding:10px 0;color:#718078">Anreise</td><td style="padding:10px 0;font-weight:700">${escapeHtml(r.arrival)}</td></tr>
        <tr><td style="padding:10px 0;color:#718078">Abreise</td><td style="padding:10px 0;font-weight:700">${escapeHtml(r.departure)}</td></tr>
        <tr><td style="padding:10px 0;color:#718078">Gäste</td><td style="padding:10px 0">${r.guests}</td></tr>
      </table>
      <div style="margin-top:20px;padding:18px;background:#f5f8f6;border-radius:14px">
        <strong>Nachricht</strong>
        <div style="margin-top:8px;white-space:pre-wrap">${escapeHtml(r.message || "Keine zusätzlichen Wünsche.")}</div>
      </div>
      <p style="margin-top:24px;color:#718078;font-size:12px">Diese Anfrage wurde über die Website von Apartman Benjo gesendet.</p>
    </div>
  </div>`;
}

function guestMailHtml(r) {
  return `
  <div style="font-family:Arial,sans-serif;background:#f4f6f5;padding:28px">
    <div style="max-width:640px;margin:auto;background:#fff;border-radius:18px;padding:28px;border:1px solid #e3e8e5">
      <div style="font-size:12px;color:#2b6553;font-weight:700;letter-spacing:1.5px">APARTMAN BENJO · HERMAGOR</div>
      <h1 style="margin:8px 0 16px;color:#173a2f">Vielen Dank für Ihre Anfrage.</h1>
      <p style="color:#526159;line-height:1.7">Hallo ${escapeHtml(r.name)}, Ihre Buchungsanfrage wurde erfolgreich übermittelt. Wir melden uns so bald wie möglich bei Ihnen.</p>
      <div style="margin:22px 0;padding:18px;background:#f5f8f6;border-radius:14px;color:#25352f">
        <strong>Anfrage #${r.id}</strong><br>
        Anreise: ${escapeHtml(r.arrival)}<br>
        Abreise: ${escapeHtml(r.departure)}<br>
        Gäste: ${r.guests}
      </div>
      <p style="color:#526159;line-height:1.7">Apartman Benjo<br>14 Hauptstraße, 9620 Hermagor<br>Telefon: +43 676 911 5665</p>
      <p style="color:#7a8982;font-size:12px">Diese E-Mail bestätigt den Eingang Ihrer Anfrage und ist noch keine verbindliche Reservierungsbestätigung.</p>
    </div>
  </div>`;
}

app.post("/api/reservations", bookingLimiter, async (req, res) => {
  try {
    const website = cleanText(req.body.website, 200);
    if (website) return res.status(200).json({ ok: true, id: 0 });

    const name = cleanText(req.body.name, 120);
    const email = cleanText(req.body.email, 180).toLowerCase();
    const arrival = cleanText(req.body.arrival, 10);
    const departure = cleanText(req.body.departure, 10);
    const guests = Number(req.body.guests);
    const message = cleanText(req.body.message, 3000);

    if (!name || !validEmail(email) || !arrival || !departure || !Number.isInteger(guests) || guests < 1 || guests > 4) {
      return res.status(400).json({ error: "Bitte prüfen Sie Name, E-Mail, Reisedaten und Gästeanzahl." });
    }
    if (departure <= arrival) {
      return res.status(400).json({ error: "Das Abreisedatum muss nach dem Anreisedatum liegen." });
    }

    const insert = db.prepare(`
      INSERT INTO reservations (name, guest_email, arrival, departure, guests, message)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const info = insert.run(name, email, arrival, departure, guests, message);
    const id = Number(info.lastInsertRowid);

    const reservation = { id, name, email, arrival, departure, guests, message };

    try {
      const transporter = getTransporter();

      await transporter.sendMail({
        from: `"Apartman Benjo Website" <${SMTP_USER}>`,
        to: OWNER_EMAIL,
        replyTo: email,
        subject: `Neue Buchungsanfrage #${id}: ${name} · ${arrival}–${departure}`,
        text:
`Neue Buchungsanfrage #${id}

Name: ${name}
E-Mail: ${email}
Anreise: ${arrival}
Abreise: ${departure}
Gäste: ${guests}

Nachricht:
${message || "Keine zusätzlichen Wünsche."}`,
        html: ownerMailHtml(reservation)
      });

      await transporter.sendMail({
        from: `"Apartman Benjo" <${SMTP_USER}>`,
        to: email,
        replyTo: OWNER_EMAIL,
        subject: `Ihre Anfrage bei Apartman Benjo #${id}`,
        text:
`Hallo ${name},

Ihre Buchungsanfrage wurde erfolgreich übermittelt.

Anfrage #${id}
Anreise: ${arrival}
Abreise: ${departure}
Gäste: ${guests}

Wir melden uns so bald wie möglich.

Apartman Benjo
14 Hauptstraße, 9620 Hermagor
+43 676 911 5665`,
        html: guestMailHtml(reservation)
      });

      db.prepare("UPDATE reservations SET email_status = 'sent' WHERE id = ?").run(id);
      return res.status(201).json({ ok: true, id });
    } catch (mailError) {
      console.error("E-Mail error:", mailError);
      db.prepare("UPDATE reservations SET email_status = 'failed' WHERE id = ?").run(id);
      return res.status(503).json({
        error: "Die Anfrage wurde in der Datenbank gespeichert, aber die E-Mail konnte nicht gesendet werden. Bitte SMTP-Konfiguration prüfen.",
        id
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Serverfehler. Bitte versuchen Sie es erneut." });
  }
});

function requireAdmin(req, res, next) {
  const supplied = req.get("x-admin-key") || "";
  if (!ADMIN_KEY || supplied !== ADMIN_KEY) {
    return res.status(401).json({ error: "Nicht autorisiert." });
  }
  next();
}

app.get("/api/reservations", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT id, name, guest_email AS email, arrival, departure, guests, message, status, email_status, created_at
    FROM reservations
    ORDER BY id DESC
    LIMIT 500
  `).all();
  res.json({ reservations: rows });
});

app.patch("/api/reservations/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const allowed = new Set(["new", "confirmed", "cancelled", "completed"]);
  const status = cleanText(req.body.status, 20);
  if (!Number.isInteger(id) || !allowed.has(status)) {
    return res.status(400).json({ error: "Ungültige Eingabe." });
  }
  const info = db.prepare("UPDATE reservations SET status = ? WHERE id = ?").run(status, id);
  if (!info.changes) return res.status(404).json({ error: "Reservierung nicht gefunden." });
  res.json({ ok: true });
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, database: DB_PATH, emailConfigured: Boolean(SMTP_USER && SMTP_PASS) });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Apartman Benjo running on http://localhost:${PORT}`);
  console.log(`Database: ${DB_PATH}`);
  console.log(`Owner email: ${OWNER_EMAIL}`);
});
